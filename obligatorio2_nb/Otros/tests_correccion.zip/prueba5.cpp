#include <stdlib.h>
#include <stdio.h>

#include "utils.h"

Mundo* crear_mundo ();

/* Definicion del mundo */
#define CANT_TERRITORIOS 1000

/* Camino mas corto */
#define T1 249			/* Territorio origen */
#define T2 653			/* Territorio destino */
#define HOSTIL "c31"		/* Comunidad hostil */
#define LARGO_CAMINO 2          /* Largo del camino más corto entre T1 y T2 */

int
main (int argc, char *argv[])
{
  int i, res;
  Mundo *m;

  for (i = 0; i < 20; i++)
    {
      m = crear_mundo ();
      destruirMundo (m);
    }

  m = crear_mundo ();
  
  printf ("Calculando camino mas corto...");
  Camino *c = caminoMasCorto (m, T1, T2, HOSTIL);
  res = check_camino (m, T1, T2, HOSTIL, LARGO_CAMINO, c);
  if (res == CHECK_OK)
    printf ("OK\n");
  else
    printf ("ERROR\n(%s)\n", STR_ERRORS[res]);
  delete [] c->territorios;
  delete c;

  printf ("Calculando proyecto de pavimentacion...");
  Mundo *pavimentado = proyectoDePavimentacion (m);
  res = check_pavimentacion (m, pavimentado);
  if (res == CHECK_OK)
    printf ("OK\n");
  else
    printf ("ERROR\n(%s)\n", STR_ERRORS[res]);

  destruirMundo (m);
  destruirMundo (pavimentado);

  return 0;
}


Mundo *
crear_mundo ()
{
  int i, j;
  Mundo *m = crearMundo (CANT_TERRITORIOS);

  char *nombre = (char*) malloc (sizeof (char)*20);
  char *comunidad = (char*) malloc (sizeof (char)*20);
  
  for (i = 0; i < CANT_TERRITORIOS; i++)
    {
      Territorio *t = obtenerTerritorioMundo (m, i);
      snprintf (nombre, 20, "t%d", i);
      snprintf (comunidad, 20, "c%d", i);
      asignarNombreTerritorio (t, nombre);
      asignarComunidadTerritorio (t, comunidad);

      for (j = i+1; j < CANT_TERRITORIOS; j++)
	hacerVecinosTerritorios (m, i, j);
    }

  free (nombre); free (comunidad);
  return m;
}

